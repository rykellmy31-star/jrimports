import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { products } from '@/db/schema';
import { eq } from 'drizzle-orm';
import fs from 'fs';
import path from 'path';
import sharp from 'sharp';

const ADMIN_KEY = process.env.ADMIN_PASSWORD || 'meu_segredo_2025_sexuz';
const UPLOAD_DIR = path.join(process.cwd(), 'public', 'uploads');

function checkAdmin(request: NextRequest): boolean {
  return (request.headers.get('x-admin-key') || '') === ADMIN_KEY;
}

export async function POST(request: NextRequest) {
  if (!checkAdmin(request)) return NextResponse.json({ error: 'Acesso negado' }, { status: 403 });

  try {
    const formData = await request.formData();
    const file = formData.get('image') as File;
    const idStr = formData.get('id') as string;

    if (!file || !idStr) return NextResponse.json({ error: 'Imagem e ID obrigatórios' }, { status: 400 });

    const id = parseInt(idStr);
    const existing = await db.select().from(products).where(eq(products.id, id)).limit(1);
    if (existing.length === 0) return NextResponse.json({ error: 'Produto não encontrado' }, { status: 404 });

    // Delete old image
    const oldUrl = existing[0].imageUrl;
    if (oldUrl && oldUrl.includes('/uploads/')) {
      try { const oldPath = path.join(process.cwd(), 'public', oldUrl); if (fs.existsSync(oldPath)) fs.unlinkSync(oldPath); } catch {}
    }

    // Convert ANY file to JPG
    const bytes = await file.arrayBuffer();
    const buffer = Buffer.from(bytes);

    const processed = await sharp(buffer)
      .resize(1200, 1200, { fit: 'inside', withoutEnlargement: false })
      .jpeg({ quality: 92, progressive: true })
      .toBuffer();

    const ext = path.extname(file.name) || '.jpg';
    const fileName = `edit_${id}_${Date.now()}${ext === '.jpg' || ext === '.jpeg' ? '.jpg' : '.jpg'}`;
    const filePath = path.join(UPLOAD_DIR, fileName);
    fs.writeFileSync(filePath, processed);

    const newUrl = `/uploads/${fileName}`;
    await db.update(products).set({ imageUrl: newUrl }).where(eq(products.id, id));

    return NextResponse.json({ success: true, imageUrl: newUrl });
  } catch (error: any) {
    console.error('Image edit error:', error);
    return NextResponse.json({ error: error.message || 'Erro' }, { status: 500 });
  }
}
