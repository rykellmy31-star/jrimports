import { pgTable, serial, text, timestamp, integer } from 'drizzle-orm/pg-core';

export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  phone: text('phone').notNull().unique(),
  name: text('name'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  lastReminderSent: timestamp('last_reminder_sent'),
});

export const waterLogs = pgTable('water_logs', {
  id: serial('id').primaryKey(),
  userId: serial('user_id').references(() => users.id),
  loggedAt: timestamp('logged_at').defaultNow().notNull(),
});

export const products = pgTable('products', {
  id: serial('id').primaryKey(),
  name: text('name').notNull(),
  description: text('description'),
  aiDescription: text('ai_description'),
  imageUrl: text('image_url').notNull(),
  category: text('category'),
  price: integer('price'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const siteConfig = pgTable('site_config', {
  id: serial('id').primaryKey(),
  siteName: text('site_name').default('Lo Luxo'),
  siteSubtitle: text('site_subtitle').default('Catálogo de Produtos Premium'),
  heroTitle: text('hero_title').default('Produtos Exclusivos'),
  heroSubtitle: text('hero_subtitle').default('Explore nosso catálogo selecionado.'),
  whatsappNumber: text('whatsapp_number').default('+5511999999999'),
  whatsappButtonText: text('whatsapp_button_text').default('Quero este produto no WhatsApp'),
  whatsappMessage: text('whatsapp_message').default('Olá! Tenho interesse no produto "{nome}" do catálogo Lo Luxo. Pode me enviar mais informações?'),
  footerText: text('footer_text').default('Lo Luxo · Catálogo Premium'),
  siteImageUrl: text('site_image_url'),
  siteBackgroundColor: text('site_background_color').default('#1c1917'),
  sitePrimaryColor: text('site_primary_color').default('#fbbf24'),
  siteSecondaryColor: text('site_secondary_color').default('#b45309'),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type WaterLog = typeof waterLogs.$inferSelect;
export type Product = typeof products.$inferSelect;
export type SiteConfig = typeof siteConfig.$inferSelect;

export const adminSettings = pgTable('admin_settings', {
  id: serial('id').primaryKey(),
  adminPassword: text('admin_password').notNull().default('meu_segredo_2025_sexuz'),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});
