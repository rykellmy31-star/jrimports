'use client';
import { useState, useEffect } from 'react';

interface Product {
  id: number; name: string; description: string; aiDescription: string;
  imageUrl: string; category: string; price: number; createdAt: string;
}

export default function AdminSimple() {
  const [authenticated, setAuthenticated] = useState(false);
  const [password, setPassword] = useState('');
  const [products, setProducts] = useState<Product[]>([]);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editData, setEditData] = useState({ name: '', desc: '', cat: '', price: '' });
  const [editFile, setEditFile] = useState<File | null>(null);
  const [msg, setMsg] = useState('');

  useEffect(() => { const s = sessionStorage.getItem('admin_token'); if (s) setAuthenticated(true); }, []);
  useEffect(() => { if (authenticated) load(); }, [authenticated]);

  const load = async () => {
    const res = await fetch('/api/admin/products', { headers: { 'X-Admin-Key': 'meu_segredo_2025_sexuz' } });
    const d = await res.json();
    setProducts(d.products || []);
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await fetch('/api/admin/auth', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ password }) });
    const d = await res.json();
    if (d.ok) { sessionStorage.setItem('admin_token', d.token); setAuthenticated(true); setPassword(''); setMsg('Login OK'); }
    else setMsg('Senha errada');
  };

  const saveEdit = async (id: number) => {
    try {
      // Upload photo if selected
      if (editFile) {
        const fd = new FormData(); fd.append('id', String(id)); fd.append('image', editFile);
        await fetch('/api/admin/products/image', { method: 'POST', headers: { 'X-Admin-Key': 'meu_segredo_2025_sexuz' }, body: fd });
      }
      // Save data
      await fetch('/api/admin/products', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', 'X-Admin-Key': 'meu_segredo_2025_sexuz' },
        body: JSON.stringify({ id, name: editData.name, description: editData.desc, category: editData.cat, price: parseInt(editData.price || '0') }),
      });
      setMsg('Atualizado!');
      setEditingId(null);
      setEditFile(null);
      load();
    } catch (e) { setMsg('Erro ao salvar'); }
  };

  const deleteP = async (id: number) => {
    if (!confirm('Excluir?')) return;
    await fetch('/api/admin/products', { method: 'DELETE', headers: { 'Content-Type': 'application/json', 'X-Admin-Key': 'meu_segredo_2025_sexuz' }, body: JSON.stringify({ id }) });
    load();
  };

  if (!authenticated) {
    return (
      <div className="min-h-screen bg-stone-950 flex items-center justify-center p-6">
        <div className="max-w-md w-full bg-stone-900 border border-stone-800 rounded-3xl p-10 shadow-2xl">
          <div className="text-center mb-8"><div className="text-6xl mb-4">👤</div><h1 className="text-3xl font-black text-amber-50">Admin</h1><p className="text-stone-500 text-sm mt-2">Painel de edição</p></div>
          <form onSubmit={handleLogin} className="space-y-4">
            <input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Senha" className="w-full px-4 py-3 bg-stone-950 border border-stone-700 rounded-xl text-amber-100" required />
            <button type="submit" className="w-full py-3 bg-amber-400 text-stone-950 font-black rounded-xl">Entrar</button>
          </form>
          {msg && <div className="mt-3 text-amber-300 text-sm text-center">{msg}</div>}
          <div className="mt-6 text-center"><a href="/" className="text-amber-300 text-sm">← Catálogo</a></div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-stone-950 text-amber-50 p-6 font-sans">
      <header className="max-w-6xl mx-auto flex items-center justify-between mb-8">
        <div><h1 className="text-3xl font-black">Admin 👤</h1><p className="text-xs text-stone-500">Edição direta — sem modal</p></div>
        <a href="/" className="px-4 py-2 bg-stone-800 rounded-xl text-sm border border-stone-700">Catálogo →</a>
      </header>

      <main className="max-w-6xl mx-auto space-y-6">
        {msg && <div className="bg-amber-500/10 text-amber-300 px-4 py-3 rounded-xl text-sm font-medium border border-amber-500/20">{msg}</div>}

        <div className="bg-stone-900 border border-stone-800 rounded-3xl p-6 shadow-xl">
          <h2 className="text-xl font-black mb-4">📋 Produtos — Editar direto na tabela</h2>
          <div className="overflow-x-auto rounded-2xl border border-stone-800">
            <table className="w-full text-sm text-left">
              <thead className="bg-stone-900 text-xs uppercase text-amber-200/40 font-bold"><tr><th className="px-4 py-3">Produto</th><th className="px-4 py-3">Cat.</th><th className="px-4 py-3">Preço</th><th className="px-4 py-3">Foto Atual</th><th className="px-4 py-3">Ações</th></tr></thead>
              <tbody className="divide-y divide-stone-800 bg-stone-900/30">
                {products.map(p => (
                  <tr key={p.id} className="hover:bg-stone-800/30">
                    {editingId === p.id ? (
                      <>
                        <td className="px-4 py-3"><input value={editData.name} onChange={e=>setEditData({ ...editData, name: e.target.value })} className="w-full px-2 py-1 bg-stone-950 border border-stone-700 rounded text-amber-100 text-sm" /></td>
                        <td className="px-4 py-3"><input value={editData.cat} onChange={e=>setEditData({ ...editData, cat: e.target.value })} className="w-full px-2 py-1 bg-stone-950 border border-stone-700 rounded text-amber-100 text-sm" /></td>
                        <td className="px-4 py-3"><input value={editData.price} onChange={e=>setEditData({ ...editData, price: e.target.value })} className="w-full px-2 py-1 bg-stone-950 border border-stone-700 rounded text-amber-100 text-sm" /></td>
                        <td className="px-4 py-3">
                          <img src={p.imageUrl} alt={p.name} className="w-12 h-12 rounded object-cover mb-1" />
                          <input type="file" accept="*/*" onChange={e=>{const f=e.target.files?.[0]; if(f){setEditFile(f); setEditData({...editData, desc: editData.desc})}}} className="text-xs text-amber-300" />
                        </td>
                        <td className="px-4 py-3 space-x-2 whitespace-nowrap">
                          <button onClick={()=>saveEdit(p.id)} className="px-3 py-1 bg-amber-400 text-stone-950 font-black rounded-lg text-xs">💾 Salvar</button>
                          <button onClick={()=>{setEditingId(null);setEditFile(null);}} className="px-3 py-1 bg-stone-800 text-amber-200 rounded-lg text-xs">Cancelar</button>
                        </td>
                      </>
                    ) : (
                      <>
                        <td className="px-4 py-3 font-medium">{p.name}</td>
                        <td className="px-4 py-3 text-xs text-stone-400">{p.category||'-'}</td>
                        <td className="px-4 py-3 font-bold text-amber-300">R$ {p.price}</td>
                        <td className="px-4 py-3"><img src={p.imageUrl} alt={p.name} className="w-12 h-12 rounded-lg object-cover" /></td>
                        <td className="px-4 py-3 space-x-2 whitespace-nowrap">
                          <button onClick={()=>{setEditingId(p.id); setEditData({name:p.name, desc:p.description||p.aiDescription||'', cat:p.category||'', price:String(p.price||'')}); setEditFile(null);}} className="px-3 py-1 bg-blue-500/10 text-blue-300 font-bold rounded-lg text-xs hover:bg-blue-500/20">✏️ Editar</button>
                          <button onClick={()=>deleteP(p.id)} className="px-3 py-1 bg-red-500/10 text-red-400 font-bold rounded-lg text-xs hover:bg-red-500/20">🗑 Excluir</button>
                        </td>
                      </>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </main>
    </div>
  );
}
