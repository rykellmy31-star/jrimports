import { NextResponse } from 'next/server';
import { db } from '@/db';
import { users } from '@/db/schema';
import { eq, lt, isNull, or } from 'drizzle-orm';
import twilio from 'twilio';

const accountSid = process.env.TWILIO_ACCOUNT_SID;
const authToken = process.env.TWILIO_AUTH_TOKEN;
const twilioPhone = process.env.TWILIO_PHONE_NUMBER;

export async function POST() {
  // If Twilio is not configured, return 0 (graceful handling)
  if (!accountSid || !authToken || !twilioPhone || accountSid === 'your_account_sid') {
    return NextResponse.json({ 
      sent: 0, 
      results: [], 
      note: 'Twilio não configurado. Configure TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN e TWILIO_PHONE_NUMBER no .env'
    });
  }

  const client = twilio(accountSid, authToken);
  const thirtyMinutesAgo = new Date(Date.now() - 30 * 60 * 1000);

  const usersToRemind = await db
    .select()
    .from(users)
    .where(
      or(
        isNull(users.lastReminderSent),
        lt(users.lastReminderSent, thirtyMinutesAgo)
      )
    );

  // Filter out demo phone numbers
  const realUsers = usersToRemind.filter(u => !u.phone.includes('0000'));

  const results = [];

  for (const user of realUsers) {
    try {
      await client.messages.create({
        body: `💧 Lembrete de Água!\n\nHora de beber um copo de água! Seu corpo agradece.\n\nAbra o app e registre: 💧 Bebi Água!`,
        from: twilioPhone,
        to: user.phone,
      });

      await db
        .update(users)
        .set({ lastReminderSent: new Date() })
        .where(eq(users.id, user.id));

      results.push({ phone: user.phone, status: 'sent' });
    } catch (error) {
      results.push({ phone: user.phone, status: 'error', error: String(error) });
    }
  }

  return NextResponse.json({ sent: results.length, results });
}

export async function GET() {
  return POST();
}
