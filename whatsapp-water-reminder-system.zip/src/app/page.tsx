'use client';

import { useState, useEffect } from 'react';

interface Product {
  id: number;
  name: string;
  description: string;
  aiDescription: string;
  imageUrl: string;
  category: string;
  price: number;
  createdAt: string;
}

export default function CatalogPublic() {
  const [products, setProducts] = useState<Product[]>([]);
  const [whatsappNumber, setWhatsappNumber] = useState('+5511999999999');
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('Todos');
  const [siteConf, setSiteConf] = useState<any>({});

  useEffect(() => {
    fetch('/api/products')
      .then(r => r.json())
      .then(data => setProducts(data.products || []))
      .catch(() => setProducts([]))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    fetch('/api/site')
      .then(r => r.json())
      .then(data => {
        if (data.config) {
          setSiteConf(data.config);
          if (data.config.whatsappNumber) setWhatsappNumber(data.config.whatsappNumber);
        }
      })
      .catch(() => {});
  }, []);

  const categories = ['Todos', ...Array.from(new Set(products.map(p => p.category || 'Geral').filter(Boolean)))];

  const filtered = filter === 'Todos' ? products : products.filter(p => (p.category || 'Geral') === filter);

  const openWhatsApp = (name: string) => {
    let msg = (siteConf.whatsappMessage || 'Olá! Tenho interesse no produto "{nome}" do catálogo Lo Luxo. Pode me enviar mais informações?').replace('{nome}', name);
    const msgEnc = encodeURIComponent(msg);
    window.open(`https://wa.me/${(whatsappNumber || siteConf.whatsappNumber || '+5511999999999').replace(/\D/g, '')}?text=${msgEnc}`, '_blank');
  };

  const formatPrice = (p: number) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(p || 0);

  return (
    <div className="min-h-screen font-sans selection:bg-amber-400/20" style={{
      backgroundColor: siteConf.siteBackgroundColor || '#1c1917',
      backgroundImage: siteConf.siteImageUrl ? `url(${siteConf.siteImageUrl})` : 'none',
      backgroundSize: 'cover',
      backgroundPosition: 'center',
      backgroundBlendMode: siteConf.siteImageUrl ? 'overlay' : 'normal',
    }}>
      {/* Header with admin link */}
      <header className="sticky top-0 z-40 bg-stone-950/80 backdrop-blur-xl border-b border-amber-900/10">
        <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
          <div>
            <a href="/" className="group">
              <h1 className="text-2xl font-black tracking-tight text-amber-100 leading-none">{siteConf.siteName || 'Lo Luxo'}</h1>
              <p className="text-xs text-amber-200/30 mt-1">{siteConf.siteSubtitle || 'Catálogo de Produtos Premium'}</p>
            </a>
          </div>
          <a href="/admin" className="text-xs px-3 py-1.5 bg-stone-800 hover:bg-stone-700 text-amber-300 rounded-lg border border-stone-700 transition-all font-medium">Área Admin →</a>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-6 py-12 space-y-16">
        {/* Hero */}
        <section className="text-center py-8 md:py-16">
          <h2 className="text-5xl md:text-7xl font-black tracking-tighter text-amber-50 leading-[0.9] mb-6">
            {siteConf.heroTitle || 'Produtos Exclusivos'}
          </h2>
          <p className="text-amber-200/50 text-lg max-w-xl mx-auto leading-relaxed">{siteConf.heroSubtitle || 'Explore nosso catálogo selecionado. Cada item é cuidadosamente descrito para você.'}</p>
        </section>

        {/* Filters */}
        <div className="flex flex-wrap gap-2 justify-center">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setFilter(cat)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                filter === cat
                  ? 'bg-amber-400 text-stone-950 shadow-lg shadow-amber-400/30'
                  : 'bg-stone-800 text-amber-200/60 hover:text-amber-100 hover:bg-stone-700 border border-stone-700'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Products Grid */}
        {loading ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[1, 2, 3, 4, 5, 6].map(i => (
              <div key={i} className="bg-stone-800/30 rounded-3xl overflow-hidden border border-stone-800/50 animate-pulse">
                <div className="aspect-[4/5] bg-stone-800" />
                <div className="p-6 space-y-3"><div className="h-6 bg-stone-700 rounded-lg w-3/4" /><div className="h-4 bg-stone-700 rounded-lg w-full" /><div className="h-4 bg-stone-700 rounded-lg w-5/6" /></div>
              </div>
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-20 bg-stone-800/20 rounded-3xl border border-dashed border-stone-700">
            <span className="text-6xl">📷</span>
            <h3 className="text-xl font-bold text-amber-100 mt-4">Nenhum produto encontrado</h3>
            <p className="text-amber-200/40">Tente outra categoria.</p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filtered.map(product => (
              <article key={product.id} className="group bg-stone-900/60 border border-stone-800/60 rounded-3xl overflow-hidden hover:border-amber-400/20 transition-all hover:-translate-y-1 hover:shadow-2xl hover:shadow-amber-900/10">
                <div className="relative aspect-[4/5] overflow-hidden">
                  <img src={product.imageUrl} alt={product.name} className="w-full h-full object-cover group-hover:scale-[1.05] transition-transform duration-700" />
                  <div className="absolute inset-0 bg-gradient-to-t from-stone-950/60 via-transparent to-transparent" />
                  <div className="absolute top-3 left-3">
                    <span className="px-3 py-1 bg-black/50 backdrop-blur-md text-amber-200 text-xs font-bold rounded-full border border-white/5">{product.category || 'Geral'}</span>
                  </div>
                  <div className="absolute top-3 right-3">
                    <span className="px-3 py-1 bg-amber-400 text-stone-950 font-black rounded-xl text-sm shadow-lg shadow-amber-400/20">{formatPrice(product.price || 0)}</span>
                  </div>
                </div>
                
                <div className="p-6 space-y-3">
                  <h3 className="text-xl font-black text-amber-50 leading-tight">{product.name}</h3>
                  <p className="text-sm text-amber-200/60 leading-relaxed line-clamp-3">{product.aiDescription || product.description || 'Produto exclusivo.'}</p>
                  
                    <button
                    onClick={() => openWhatsApp(product.name)}
                    className="w-full mt-2 py-3 text-white font-black rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 active:scale-[0.98]"
                    style={{ background: `linear-gradient(to right, ${siteConf.sitePrimaryColor || '#10b981'}, ${siteConf.siteSecondaryColor || '#14b8a6'})` }}
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
                    {siteConf.whatsappButtonText || 'Quero este produto no WhatsApp'}
                  </button>
                </div>
              </article>
            ))}
          </div>
        )}
      </main>

      <footer className="text-center text-stone-600 text-xs py-8 border-t border-stone-800/50">
        {siteConf.footerText || 'Lo Luxo — Catálogo Premium · Produtos selecionados com descrição por IA'}
      </footer>
    </div>
  );
}
