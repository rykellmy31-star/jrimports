import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { products } from '@/db/schema';
import { eq } from 'drizzle-orm';
import fs from 'fs';
import path from 'path';

const ADMIN_KEY = process.env.ADMIN_PASSWORD || 'meu_segredo_2025_sexuz';
const UPLOAD_DIR = path.join(process.cwd(), 'public', 'uploads');

function checkAdmin(request: NextRequest): boolean {
  const key = request.headers.get('x-admin-key') || '';
  return key === ADMIN_KEY;
}

export async function GET(request: NextRequest) {
  if (!checkAdmin(request)) {
    return NextResponse.json({ error: 'Acesso negado' }, { status: 403 });
  }
  
  const all = await db.select().from(products).orderBy(products.createdAt);
  return NextResponse.json({ products: all });
}

export async function POST(request: NextRequest) {
  if (!checkAdmin(request)) {
    return NextResponse.json({ error: 'Acesso negado' }, { status: 403 });
  }
  
  try {
    const formData = await request.formData();
    const file = formData.get('image') as File;
    const name = (formData.get('name') as string) || 'Produto';
    const category = (formData.get('category') as string) || 'Geral';
    const priceStr = (formData.get('price') as string) || '0';
    
    if (!file) {
      return NextResponse.json({ error: 'Nenhuma imagem' }, { status: 400 });
    }
    
    const bytes = await file.arrayBuffer();
    const buffer = Buffer.from(bytes);
    const fileName = `${Date.now()}_${file.name.replace(/[^a-zA-Z0-9.-]/g, '_')}`;
    const filePath = path.join(UPLOAD_DIR, fileName);
    fs.writeFileSync(filePath, buffer);
    
    const imageUrl = `/uploads/${fileName}`;
    
    // Auto description fallback
    const aiDescription = `Produto exclusivo: ${name}. Design elegante, qualidade premium e experiência única para quem busca o melhor.`;
    
    const [product] = await db.insert(products).values({
      name,
      description: aiDescription,
      aiDescription,
      imageUrl,
      category,
      price: parseInt(priceStr) || 0,
    }).returning();
    
    return NextResponse.json({ success: true, product });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Erro' }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  if (!checkAdmin(request)) return NextResponse.json({ error: 'Acesso negado' }, { status: 403 });
  
  try {
    const body = await request.json();
    const id = body.id;
    if (!id) return NextResponse.json({ error: 'ID necessário' }, { status: 400 });
    
    await db.update(products).set({
      name: body.name,
      description: body.description,
      aiDescription: body.aiDescription || body.description,
      category: body.category,
      price: body.price ? parseInt(String(body.price)) : undefined,
    }).where(eq(products.id, id));
    
    const updated = await db.select().from(products).where(eq(products.id, id)).limit(1);
    return NextResponse.json({ success: true, product: updated[0] });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Erro' }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  if (!checkAdmin(request)) {
    return NextResponse.json({ error: 'Acesso negado' }, { status: 403 });
  }
  
  try {
    const { id } = await request.json();
    if (!id) return NextResponse.json({ error: 'ID necessário' }, { status: 400 });
    
    // Get product to delete image file
    const existing = await db.select().from(products).where(eq(products.id, id)).limit(1);
    if (existing.length > 0) {
      const imgPath = existing[0].imageUrl;
      if (imgPath && imgPath.includes('/uploads/')) {
        const filePath = path.join(process.cwd(), 'public', imgPath);
        try { if (fs.existsSync(filePath)) fs.unlinkSync(filePath); } catch {}
      }
    }
    
    await db.delete(products).where(eq(products.id, id));
    return NextResponse.json({ success: true });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Erro' }, { status: 500 });
  }
}
