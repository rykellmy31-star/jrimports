import { NextResponse } from 'next/server';
import { db } from '@/db';
import { siteConfig } from '@/db/schema';

export async function GET() {
  try {
    const conf = await db.select().from(siteConfig).limit(1);
    return NextResponse.json({ config: conf[0] || {} });
  } catch {
    return NextResponse.json({ config: {} });
  }
}
