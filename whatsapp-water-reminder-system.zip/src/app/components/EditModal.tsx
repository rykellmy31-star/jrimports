'use client';

import { useState, useEffect } from 'react';

interface Product {
  id: number; name: string; description: string; aiDescription: string;
  imageUrl: string; category: string; price: number; createdAt: string;
}

export default function EditModal({ product, onClose, onUpdated }: { product: Product; onClose: () => void; onUpdated: () => void }) {
  const [name, setName] = useState(product.name);
  const [desc, setDesc] = useState(product.description || product.aiDescription || '');
  const [cat, setCat] = useState(product.category || '');
  const [price, setPrice] = useState(String(product.price || ''));
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState('');
  const [msg, setMsg] = useState('');

  const uploadImage = async () => {
    if (!file) return false;
    const fd = new FormData(); fd.append('id', String(product.id)); fd.append('image', file);
    try {
      const res = await fetch('/api/admin/products/image', { method: 'POST', headers: { 'X-Admin-Key': 'meu_segredo_2025_sexuz' }, body: fd });
      const data = await res.json();
      return data.success;
    } catch { return false; }
  };

  const save = async () => {
    if (file) {
      const ok = await uploadImage();
      if (!ok) { setMsg('Erro ao atualizar foto'); return; }
    }
    try {
      await fetch('/api/admin/products', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', 'X-Admin-Key': 'meu_segredo_2025_sexuz' },
        body: JSON.stringify({ id: product.id, name, description: desc, category: cat, price: parseInt(price || '0') }),
      });
      setMsg('Salvo!');
      onUpdated();
      onClose();
    } catch { setMsg('Erro'); }
  };

  return (
    <div className="fixed inset-0 z-[100] bg-black/70 backdrop-blur-sm flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-stone-900 border border-stone-700 rounded-3xl max-w-lg w-full p-8 shadow-2xl" onClick={e => e.stopPropagation()}>
        <h3 className="text-2xl font-black text-amber-100 mb-4">Editar: {product.name}</h3>
        <div className="space-y-3">
          <input value={name} onChange={e => setName(e.target.value)} className="w-full px-4 py-2 bg-stone-950 border border-stone-700 rounded-xl text-amber-100 text-sm" />
          <textarea value={desc} onChange={e => setDesc(e.target.value)} rows={3} className="w-full px-4 py-2 bg-stone-950 border border-stone-700 rounded-xl text-amber-100 text-sm resize-none" />
          <div className="grid grid-cols-2 gap-3">
            <input value={cat} onChange={e => setCat(e.target.value)} className="w-full px-4 py-2 bg-stone-950 border border-stone-700 rounded-xl text-amber-100 text-sm" placeholder="Categoria" />
            <input value={price} onChange={e => setPrice(e.target.value)} className="w-full px-4 py-2 bg-stone-950 border border-stone-700 rounded-xl text-amber-100 text-sm" placeholder="Preço" />
          </div>
          
          <div className="pt-2 border-t border-stone-700">
            <label className="text-xs font-bold text-amber-200/40 mb-2 block">Nova Foto (qualquer arquivo)</label>
            <div className="flex gap-3 items-center">
              <div className="w-16 h-16 rounded-xl overflow-hidden border border-stone-700 bg-stone-950 flex-shrink-0">
                <img src={preview || product.imageUrl || '/uploads/demo_perfume.jpg'} alt="produto" className="w-full h-full object-cover" onError={(e) => { (e.target as HTMLImageElement).src = '/uploads/demo_perfume.jpg'; }} />
              </div>
              <div>
                <input type="file" accept="*/*" onChange={e => { const f = e.target.files?.[0]; if (f) { setFile(f); setPreview(URL.createObjectURL(f)); } }} className="hidden" id="editNewFile" />
                <label htmlFor="editNewFile" className="px-3 py-2 bg-stone-800 hover:bg-stone-700 text-amber-200 rounded-lg text-xs font-medium cursor-pointer border border-stone-700 transition-all">📷 Escolher Nova Foto</label>
                {file && <span className="text-xs text-amber-300 ml-2">{file.name}</span>}
              </div>
            </div>
          </div>
          
          <div className="flex gap-3 pt-2">
            <button onClick={save} className="flex-1 py-3 bg-gradient-to-r from-amber-400 to-amber-500 text-stone-950 font-black rounded-xl">💾 Salvar Tudo</button>
            <button onClick={onClose} className="flex-1 py-3 bg-stone-800 hover:bg-stone-700 text-amber-200 font-bold rounded-xl">Cancelar</button>
          </div>
          {msg && <div className="text-sm text-amber-300 font-medium text-center">{msg}</div>}
        </div>
      </div>
    </div>
  );
}
