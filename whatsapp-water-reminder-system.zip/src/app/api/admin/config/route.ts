import { NextResponse } from 'next/server';
import { db } from '@/db';
import { siteConfig } from '@/db/schema';
import fs from 'fs';
import path from 'path';
import sharp from 'sharp';
import { eq } from 'drizzle-orm';

const ADMIN_KEY = process.env.ADMIN_PASSWORD || 'meu_segredo_2025_sexuz';
const UPLOAD_DIR = path.join(process.cwd(), 'public', 'uploads');
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });

export async function POST(request: Request) {
  try {
    const formData = await request.formData();
    const file = formData.get('siteImage') as File;
    const auth = request.headers.get('x-admin-key') || '';
    if (auth !== ADMIN_KEY) return NextResponse.json({ error: 'Acesso negado' }, { status: 403 });

    if (!file) return NextResponse.json({ error: 'Nenhuma imagem' }, { status: 400 });

    const bytes = await file.arrayBuffer();
    const buffer = Buffer.from(bytes);

    // Convert ANY file to high-quality JPG
    const processed = await sharp(buffer)
      .resize(1600, 900, { fit: 'inside', withoutEnlargement: false })
      .jpeg({ quality: 92, progressive: true })
      .toBuffer();

    const fileName = `site_bg_${Date.now()}.jpg`;
    const filePath = path.join(UPLOAD_DIR, fileName);
    fs.writeFileSync(filePath, processed);
    const imageUrl = `/uploads/${fileName}`;

    const existing = await db.select().from(siteConfig).limit(1);
    if (existing.length === 0) {
      await db.insert(siteConfig).values({ siteImageUrl: imageUrl, updatedAt: new Date() });
    } else {
      await db.update(siteConfig).set({ siteImageUrl: imageUrl, updatedAt: new Date() }).where(eq(siteConfig.id, existing[0].id));
    }

    return NextResponse.json({ success: true, imageUrl, message: 'Imagem convertida para JPG automaticamente!' });
  } catch (error: any) {
    console.error('Site image error:', error);
    return NextResponse.json({ error: error.message || 'Erro' }, { status: 500 });
  }
}
