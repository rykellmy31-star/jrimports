import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { users, waterLogs } from '@/db/schema';
import { eq } from 'drizzle-orm';

export async function POST(request: NextRequest) {
  const { phone } = await request.json();

  const user = await db.select().from(users).where(eq(users.phone, phone)).limit(1);

  if (user.length === 0) {
    return NextResponse.json({ error: 'User not found' }, { status: 404 });
  }

  await db.insert(waterLogs).values({ userId: user[0].id });

  return NextResponse.json({ success: true });
}
