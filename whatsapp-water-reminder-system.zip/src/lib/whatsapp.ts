export const WHATSAPP_NUMBER = process.env.WHATSAPP_NUMBER || '+5511999999999';
export const WHATSAPP_MSG = (name: string) => `Olá! Tenho interesse no produto "${name}" do catálogo Lo Luxo. Pode me enviar mais informações?`;
