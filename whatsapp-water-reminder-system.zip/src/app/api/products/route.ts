import { NextResponse } from 'next/server';
import { db } from '@/db';
import { products } from '@/db/schema';
import { eq } from 'drizzle-orm';
import fs from 'fs';
import path from 'path';
import sharp from 'sharp';

const UPLOAD_DIR = path.join(process.cwd(), 'public', 'uploads');
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });

function safeFileName(originalName: string): string {
  const clean = originalName.replace(/[^a-zA-Z0-9_.-]/g, '_').replace(/_+/g, '_');
  return clean || 'image';
}

export async function POST(request: Request) {
  try {
    const formData = await request.formData();
    const file = formData.get('image') as File;
    const name = (formData.get('name') as string) || 'Produto';
    const category = (formData.get('category') as string) || 'Geral';
    const priceStr = (formData.get('price') as string) || '0';

    if (!file) return NextResponse.json({ error: 'Nenhuma imagem enviada' }, { status: 400 });

    const bytes = await file.arrayBuffer();
    const buffer = Buffer.from(bytes);

    // Convert ANY image to high-quality JPG using sharp
    const processed = await sharp(buffer)
      .resize(1200, 1200, { fit: 'inside', withoutEnlargement: false })
      .jpeg({ quality: 90, progressive: true })
      .toBuffer();

    const fileName = `prod_${Date.now()}_${safeFileName(file.name)}.jpg`;
    const filePath = path.join(UPLOAD_DIR, fileName);
    fs.writeFileSync(filePath, processed);
    const imageUrl = `/uploads/${fileName}`;

    const aiDescription = `Produto exclusivo: ${name}. Design elegante, qualidade premium e experiência única para quem busca o melhor.`;

    const [product] = await db.insert(products).values({
      name,
      description: aiDescription,
      aiDescription,
      imageUrl,
      category,
      price: parseInt(priceStr) || 0,
    }).returning();

    return NextResponse.json({ success: true, product });
  } catch (error: any) {
    console.error('Upload error:', error);
    return NextResponse.json({ error: error.message || 'Erro no upload' }, { status: 500 });
  }
}

export async function GET() {
  try {
    const allProducts = await db.select().from(products).orderBy(products.createdAt);
    return NextResponse.json({ products: allProducts });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
