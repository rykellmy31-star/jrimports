import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { users, waterLogs } from '@/db/schema';
import { eq, desc } from 'drizzle-orm';

export async function POST(request: NextRequest) {
  const { phone, name } = await request.json();

  if (!phone) {
    return NextResponse.json({ error: 'Phone is required' }, { status: 400 });
  }

  const existing = await db.select().from(users).where(eq(users.phone, phone)).limit(1);

  if (existing.length > 0) {
    return NextResponse.json({ user: existing[0] });
  }

  const [newUser] = await db.insert(users).values({ phone, name }).returning();
  return NextResponse.json({ user: newUser });
}

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const phone = searchParams.get('phone');

  if (!phone) {
    return NextResponse.json({ error: 'Phone required' }, { status: 400 });
  }

  const user = await db.select().from(users).where(eq(users.phone, phone)).limit(1);

  if (user.length === 0) {
    return NextResponse.json({ error: 'User not found' }, { status: 404 });
  }

  const logs = await db
    .select()
    .from(waterLogs)
    .where(eq(waterLogs.userId, user[0].id))
    .orderBy(desc(waterLogs.loggedAt))
    .limit(20);

  return NextResponse.json({ user: user[0], logs });
}
