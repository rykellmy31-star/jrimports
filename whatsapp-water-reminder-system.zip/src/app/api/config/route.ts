import { NextResponse } from 'next/server';

export async function GET() {
  return NextResponse.json({ 
    number: process.env.WHATSAPP_NUMBER || '+5511999999999',
    message: 'Olá! Tenho interesse no produto "{product}" do catálogo Lo Luxo. Pode me enviar mais informações?'
  });
}
