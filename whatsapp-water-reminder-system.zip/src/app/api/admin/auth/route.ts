import { NextResponse } from 'next/server';
import { db } from '@/db';
import { adminSettings } from '@/db/schema';
import { eq } from 'drizzle-orm';

export async function POST(request: Request) {
  try {
    const { password, newPassword } = await request.json();
    
    // Read current password from DB
    const settings = await db.select().from(adminSettings).limit(1);
    const currentPassword = settings[0]?.adminPassword || process.env.ADMIN_PASSWORD || 'meu_segredo_2025_sexuz';
    
    if (newPassword) {
      // Changing password mode
      if (password !== currentPassword) {
        return NextResponse.json({ error: 'Senha atual incorreta' }, { status: 401 });
      }
      // Update in DB
      if (settings.length === 0) {
        await db.insert(adminSettings).values({ adminPassword: newPassword });
      } else {
        await db.update(adminSettings).set({ adminPassword: newPassword, updatedAt: new Date() }).where(eq(adminSettings.id, settings[0].id));
      }
      return NextResponse.json({ ok: true, message: 'Senha alterada com sucesso!' });
    } else {
      // Login mode
      if (password === currentPassword) {
        return NextResponse.json({ ok: true, token: 'admin-' + Date.now() });
      }
      return NextResponse.json({ error: 'Senha incorreta' }, { status: 401 });
    }
  } catch (e: any) {
    return NextResponse.json({ error: e.message || 'Erro' }, { status: 500 });
  }
}
